//////////////////////////
// ACCOUNTS
//////////////////////////

const accounts = {
  gijs: { password: "relatie2025", role: "admin" },
  mike: { password: "relatie2025", role: "admin" },

  emma: { password: "relatie2025", role: "lid" },
  julian: { password: "relatie2025", role: "lid" },
  julia: { password: "relatie2025", role: "lid" },
  mathijs: { password: "relatie2025", role: "lid" },
  esmee: { password: "relatie2025", role: "lid" },
  troy: { password: "relatie2025", role: "lid" },
  sophia: { password: "relatie2025", role: "lid" }
};

//////////////////////////
// DATA
//////////////////////////

let currentUser = null;

let vacatures = ["Spion", "Secretaris", "Penningmeester"];

let applications = [];
let channels = {};

let poems = [];
let activities = [];

//////////////////////////
// LOGIN
//////////////////////////

function login() {
  const username = document.getElementById("username").value.toLowerCase().trim();
  const password = document.getElementById("password").value;
  const error = document.getElementById("loginError");

  error.textContent = "";

  const account = accounts[username];

  if (!account || account.password !== password) {
    error.textContent = "❌ Inloggegevens onjuist";
    return;
  }

  currentUser = username;

  document.getElementById("loginPage").classList.add("hidden");
  document.getElementById("app").classList.remove("hidden");

  document.getElementById("userInfo").textContent =
    username.charAt(0).toUpperCase() + username.slice(1);

  const admin = account.role === "admin";

  document.getElementById("activityAdmin").classList.toggle("hidden", !admin);
  document.getElementById("poemAdmin").classList.toggle("hidden", !admin);
  document.getElementById("vacatureAdmin").classList.toggle("hidden", !admin);
  document.getElementById("applicationsCard").classList.toggle("hidden", !admin);

  // 🔥 NIEUW: accountbeheer tonen
  const accountCard = document.getElementById("accountAdminCard");
  if (accountCard) {
    accountCard.classList.toggle("hidden", !admin);
  }

  renderAll();
}

//////////////////////////
// LOGOUT
//////////////////////////

function logout() {
  currentUser = null;

  document.getElementById("app").classList.add("hidden");
  document.getElementById("loginPage").classList.remove("hidden");

  document.getElementById("loginError").textContent = "";
}

//////////////////////////
// ADMIN CHECK
//////////////////////////

function isAdmin() {
  return accounts[currentUser]?.role === "admin";
}

//////////////////////////
// VACATURES
//////////////////////////

function applyVacature(vacancy) {
  applications.push({
    id: Date.now(),
    user: currentUser,
    vacancy: vacancy
  });

  alert("Sollicitatie verstuurd!");
  renderInbox();
}

function addVacature() {
  const input = document.getElementById("vacatureInput");

  if (!input.value.trim()) return;

  vacatures.push(input.value.trim());
  input.value = "";

  renderVacatures();
}

function renderVacatures() {
  const box = document.getElementById("vacatureUser");
  if (!box) return;

  box.innerHTML = "<p>Klik op een vacature:</p>";

  vacatures.forEach(v => {
    const btn = document.createElement("button");
    btn.textContent = v;
    btn.onclick = () => applyVacature(v);
    box.appendChild(btn);
  });

  renderVacatureAdmin();
}

function renderVacatureAdmin() {
  const box = document.getElementById("vacatureList");
  if (!box) return;

  box.innerHTML = "";

  if (!isAdmin()) return;

  vacatures.forEach((v, i) => {
    const div = document.createElement("div");

    const text = document.createElement("span");
    text.textContent = v + " ";

    const del = document.createElement("button");
    del.textContent = "❌";
    del.onclick = () => {
      vacatures.splice(i, 1);
      renderVacatures();
    };

    div.appendChild(text);
    div.appendChild(del);

    box.appendChild(div);
  });
}

//////////////////////////
// INBOX
//////////////////////////

function renderInbox() {
  const box = document.getElementById("applicationsList");
  if (!box) return;

  box.innerHTML = "";

  applications.forEach(app => {

    const div = document.createElement("div");

    div.style.border = "1px solid #ccc";
    div.style.margin = "10px";
    div.style.padding = "10px";

    let html = `
      <b>Naam:</b> ${app.user}<br>
      <b>Vacature:</b> ${app.vacancy}
    `;

    if (app.email) {
      html += `<br><b>Email:</b> ${app.email}`;
    }

    if (app.reason) {
      html += `
        <br><br>
        <b>Motivatie:</b><br>
        ${app.reason}
      `;
    }

    div.innerHTML = html;

    const accept = document.createElement("button");
    accept.textContent = "✔ Goedkeuren";
    accept.onclick = () => approve(app.id);

    const reject = document.createElement("button");
    reject.textContent = "❌ Afwijzen";
    reject.onclick = () => rejectApp(app.id);

    div.appendChild(document.createElement("br"));
    div.appendChild(document.createElement("br"));

    div.appendChild(accept);
    div.appendChild(reject);

    box.appendChild(div);
  });
}

function approve(id) {
  const app = applications.find(a => a.id === id);
  if (!app) return;

  if (!channels[app.user]) {
    channels[app.user] = [];
  }

  channels[app.user].push({
    name: app.vacancy,
    messages: []
  });

  applications = applications.filter(a => a.id !== id);

  renderInbox();
  renderChannels();
}

function rejectApp(id) {
  applications = applications.filter(a => a.id !== id);
  renderInbox();
}

//////////////////////////
// KANALEN
//////////////////////////

function renderChannels() {
  const box = document.getElementById("myChannels");
  if (!box) return;

  box.innerHTML = "";

  const userChannels = channels[currentUser] || [];

  userChannels.forEach(ch => {
    const div = document.createElement("div");
    div.style.border = "1px solid black";
    div.style.margin = "10px";
    div.style.padding = "10px";

    const title = document.createElement("h3");
    title.textContent = "📌 " + ch.name;

    const msgBox = document.createElement("div");

    ch.messages.forEach(m => {
      const wrapper = document.createElement("div");
      wrapper.style.border = "1px solid #ddd";
      wrapper.style.margin = "5px";
      wrapper.style.padding = "5px";

      const text = document.createElement("span");
      text.textContent = `[${m.role}] ${m.author}: ${m.text}`;

      const del = document.createElement("button");
      del.textContent = "❌";

      del.onclick = () => {
        if (isAdmin() || m.author === currentUser) {
          ch.messages = ch.messages.filter(x => x.id !== m.id);
          renderChannels();
        } else {
          alert("Je mag dit niet verwijderen");
        }
      };

      wrapper.appendChild(text);
      wrapper.appendChild(del);

      msgBox.appendChild(wrapper);
    });

    const input = document.createElement("input");
    input.placeholder = "Plaats activiteit...";

    const btn = document.createElement("button");
    btn.textContent = "Plaatsen";

    btn.onclick = () => {
      if (!input.value.trim()) return;

      ch.messages.push({
        id: Date.now(),
        text: input.value,
        author: currentUser,
        role: accounts[currentUser].role
      });

      input.value = "";
      renderChannels();
    };

    div.appendChild(title);
    div.appendChild(msgBox);
    div.appendChild(input);
    div.appendChild(btn);

    box.appendChild(div);
  });
}

//////////////////////////
// ACCOUNTBEHEER (NIEUW)
//////////////////////////

function renderAccounts() {
  const box = document.getElementById("accountList");
  if (!box) return;

  box.innerHTML = "";

  Object.keys(accounts).forEach(name => {
    const div = document.createElement("div");
    div.style.border = "1px solid #ccc";
    div.style.margin = "5px";
    div.style.padding = "5px";

    div.innerHTML = `<b>${name}</b> (${accounts[name].role})`;

    const del = document.createElement("button");
    del.textContent = "❌ Verwijderen";

    del.onclick = () => {
      if (!isAdmin()) return;

      if (name === "gijs" || name === "mike") {
        alert("Admins kun je niet verwijderen");
        return;
      }

      delete accounts[name];
      renderAccounts();
    };

    div.appendChild(del);
    box.appendChild(div);
  });
}

//////////////////////////
// GEDICHTEN
//////////////////////////

function addPoem() {
  const input = document.getElementById("poemInput");

  if (!input.value.trim()) return;

  poems.push(input.value);

  input.value = "";

  renderPoems();
}

function renderPoems() {
  const box = document.getElementById("poemList");
  if (!box) return;

  box.innerHTML = "";

  poems.forEach(p => {
    const div = document.createElement("div");
    div.style.border = "1px solid #ddd";
    div.style.margin = "5px";
    div.style.padding = "5px";

    div.textContent = p;

    box.appendChild(div);
  });
}

//////////////////////////
// ACTIVITEITEN
//////////////////////////

function addActivity() {
  const input = document.getElementById("activityInput");

  if (!input.value.trim()) return;

  activities.push(input.value);

  input.value = "";

  renderActivities();
}

function renderActivities() {
  const box = document.getElementById("activityList");
  if (!box) return;

  box.innerHTML = "";

  activities.forEach(a => {
    const li = document.createElement("li");
    li.textContent = a;
    box.appendChild(li);
  });
}

//////////////////////////
// MASTER RENDER
//////////////////////////

function renderAll() {
  renderVacatures();
  renderInbox();
  renderChannels();
  renderPoems();
  renderActivities();
  renderAccounts(); // 🔥 belangrijk
}
//////////////////////////
// OPEN SOLLICITATIEFORMULIER
//////////////////////////

function showApplicationForm() {
  const form = document.getElementById("applicationForm");

  if (!form) return;

  form.classList.toggle("hidden");
}

//////////////////////////
// VERSTUUR OPEN SOLLICITATIE
//////////////////////////

function submitApplication() {
  const name = document.getElementById("appName").value.trim();
  const email = document.getElementById("appEmail").value.trim();
  const reason = document.getElementById("appReason").value.trim();

  if (!name || !email || !reason) {
    alert("Vul alle velden in");
    return;
  }

  applications.push({
    id: Date.now(),
    user: name,
    vacancy: "Open sollicitatie",
    email: email,
    reason: reason
  });

  document.getElementById("appName").value = "";
  document.getElementById("appEmail").value = "";
  document.getElementById("appReason").value = "";

  document.getElementById("applicationForm").classList.add("hidden");

  alert("Sollicitatie verstuurd!");

  renderInbox();
}